document.querySelector("#search-button").onclick = e => {
    searchForm.classList.toggle("active");
    searchBox.focus();
    e.preventDefault();
};

window.onscroll = function () {
    const topButton = document.getElementById("backToTop");
    if (
        document.body.scrollTop > 20 ||
        document.documentElement.scrollTop > 20
    ) {
        topButton.style.display = "block";
    } else {
        topButton.style.display = "none";
    }
};
